package br.com.unicuritiba.Livraria.models;

import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.constraints.*;

public class LivroDto {

	@NotEmpty(message = "O nome é obrigatório!")
	private String name;
	
	@NotEmpty(message = "O autor é obrigatório!")
	private String autor;
	
	@NotEmpty(message = "A editora é obrigatório!")
	private String editora;
	
	private MultipartFile imageFile;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getEditora() {
		return editora;
	}

	public void setEditora(String editora) {
		this.editora = editora;
	}

	public MultipartFile getImageFile() {
		return imageFile;
	}

	public void setImageFile(MultipartFile imageFile) {
		this.imageFile = imageFile;
	}
	
	
}
